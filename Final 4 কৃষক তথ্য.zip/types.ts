
export interface User {
  id: string;
  name: string;
  nameBangla?: string;
  photo?: string;
  fatherName?: string;
  fatherNameBangla?: string;
  motherName?: string;
  motherNameBangla?: string;
  dob?: string;
  bloodGroup?: string;
  nid?: string;
  mobile?: string;
  division?: string;
  district?: string;
  upazila?: string;
  union?: string;
  village?: string;
  postOffice?: string;
  postCode?: string;
  workDivision?: string;
  workDistrict?: string;
  workUpazila?: string;
  workUnion?: string;
  workBlock?: string;
}

export interface SeasonalService {
  season: string;
  crop: string;
  serviceCount: string;
  serviceType?: string; // New field for Incentive/Demonstration
}

export interface Farmer {
  id: string;
  photo: string | null;
  name: string;
  nameBangla: string;
  fatherHusbandName: string;
  fatherHusbandNameBangla: string;
  motherName: string;
  motherNameBangla: string;
  dob: string;
  bloodGroup: string;
  division: string;
  district: string;
  upazila: string;
  union: string;
  village: string;
  postOffice: string;
  postCode: string;
  ward: string;
  block: string;
  mobile: string;
  nid: string;
  seasonalServices: SeasonalService[];
  services: string;
  // added dateAdded to track when the farmer record was created
  dateAdded: string;
}

export type ViewState = 'LIST' | 'FORM' | 'PROFILE' | 'DETAILS';
