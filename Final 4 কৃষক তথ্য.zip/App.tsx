
import React, { useState, useEffect } from 'react';
import Login from './components/Login';
import Register from './components/Register';
import Navbar from './components/Navbar';
import FarmerList from './components/FarmerList';
import FarmerForm from './components/FarmerForm';
import UserProfile from './components/UserProfile';
import FarmerDetails from './components/FarmerDetails';
import { User, Farmer, ViewState } from './types';
import { toBengaliNumber } from './constants';

type Theme = 'light' | 'dark' | 'system';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [farmers, setFarmers] = useState<Farmer[]>([]);
  const [view, setView] = useState<ViewState>('LIST');
  const [editingFarmer, setEditingFarmer] = useState<Farmer | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [theme, setTheme] = useState<Theme>((localStorage.getItem('agro_theme') as Theme) || 'system');

  // Theme Logic
  useEffect(() => {
    const root = window.document.documentElement;
    const applyTheme = (t: Theme) => {
      if (t === 'dark' || (t === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    };

    applyTheme(theme);
    localStorage.setItem('agro_theme', theme);

    if (theme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handleChange = () => applyTheme('system');
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
  }, [theme]);

  // Load data from local storage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('agro_user');
    const savedFarmers = localStorage.getItem('agro_farmers');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
      setIsLoggedIn(true);
    }
    if (savedFarmers) {
      setFarmers(JSON.parse(savedFarmers));
    }
  }, []);

  const handleLogin = (id: string, pass: string) => {
    const savedRegistrations = localStorage.getItem('agro_registered_users_list');
    const users = savedRegistrations ? JSON.parse(savedRegistrations) : [];
    const registeredUser = users.find((u: any) => u.mobile === id);

    const user: User = { 
      id: id, 
      name: registeredUser?.name || '', 
      nameBangla: registeredUser?.name || '', 
      workUpazila: registeredUser?.workUpazila || '',
      ...registeredUser
    };
    
    setCurrentUser(user);
    setIsLoggedIn(true);
    localStorage.setItem('agro_user', JSON.stringify(user));
  };

  const handleRegisterSuccess = (name: string, mobile: string) => {
    const user: User = { 
      id: mobile, 
      name: name, 
      nameBangla: name, 
      workUpazila: '' 
    };
    setCurrentUser(user);
    setIsLoggedIn(true);
    setIsRegistering(false);
    localStorage.setItem('agro_user', JSON.stringify(user));
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    localStorage.removeItem('agro_user');
    setView('LIST');
  };

  const saveFarmers = (updatedFarmers: Farmer[]) => {
    setFarmers(updatedFarmers);
    localStorage.setItem('agro_farmers', JSON.stringify(updatedFarmers));
  };

  const addOrUpdateFarmer = (farmer: Farmer) => {
    let updated;
    if (editingFarmer && view === 'FORM') {
      updated = farmers.map(f => f.id === editingFarmer.id ? { ...farmer, id: editingFarmer.id, dateAdded: f.dateAdded } : f);
    } else {
      updated = [...farmers, { ...farmer, id: Date.now().toString(), dateAdded: new Date().toISOString() }];
    }
    saveFarmers(updated);
    setView('LIST');
    setEditingFarmer(null);
  };

  const deleteFarmer = (id: string) => {
    if (window.confirm('আপনি কি নিশ্চিত যে এই কৃষকের তথ্য মুছে ফেলতে চান?')) {
      saveFarmers(farmers.filter(f => f.id !== id));
    }
  };

  const downloadExcel = () => {
    if (farmers.length === 0) {
        alert("ডাউনলোড করার জন্য কোনো কৃষকের তথ্য নেই।");
        return;
    }
    const headers = "Name,Mobile,NID,Division,District,Upazila,Union,Village,Ward,Post Office,Post Code\n";
    const rows = farmers.map(f => 
        `${f.name},${f.mobile},${f.nid},${f.division},${f.district},${f.upazila},${f.union},${f.village},${f.ward},${f.postOffice},${f.postCode}`
    ).join("\n");
    const blob = new Blob(["\ufeff" + headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `farmers_list_${Date.now()}.csv`;
    a.click();
  };

  const filteredFarmers = farmers.filter(f => {
    const query = searchQuery.toLowerCase();
    return (
      f.mobile.includes(query) ||
      f.nid.includes(query)
    );
  });

  if (!isLoggedIn) {
    return isRegistering ? (
      <Register onRegisterSuccess={handleRegisterSuccess} onBackToLogin={() => setIsRegistering(false)} />
    ) : (
      <Login onLogin={handleLogin} onGoToRegister={() => setIsRegistering(true)} />
    );
  }

  return (
    <div className="min-h-screen pb-20 pt-20 bg-gray-50 dark:bg-slate-950 transition-colors duration-500">
      <Navbar 
        user={currentUser!} 
        onLogout={handleLogout} 
        setView={setView} 
        onDownload={downloadExcel}
        theme={theme}
        setTheme={setTheme}
      />
      
      <main className="max-w-6xl mx-auto px-4">
        {view === 'LIST' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white tracking-tight">নিবন্ধিত কৃষক তালিকা</h2>
                
                <button 
                  onClick={downloadExcel}
                  title="এক্সেল ফাইল ডাউনলোড করুন"
                  className="group relative flex items-center justify-center w-12 h-12 bg-white dark:bg-slate-900 rounded-2xl shadow-[0_10px_20px_-5px_rgba(22,163,74,0.1)] border border-green-50 dark:border-slate-800 overflow-hidden transition-all duration-500 hover:w-32 active:scale-90"
                >
                  <div className="absolute inset-0 bg-gradient-to-tr from-green-600 to-emerald-500 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <div className="flex items-center justify-center gap-2 relative z-10 transition-colors duration-500">
                    <i className="fa-solid fa-file-arrow-down text-green-600 group-hover:text-white text-xl group-hover:scale-110 transition-all duration-500"></i>
                    <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 text-white font-black text-[10px] uppercase tracking-widest whitespace-nowrap">
                      ডাউনলোড
                    </span>
                  </div>
                </button>
              </div>
              
              <button 
                onClick={() => { setEditingFarmer(null); setView('FORM'); }}
                className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-2xl font-bold shadow-xl shadow-green-100 dark:shadow-none transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                <i className="fa fa-plus-circle"></i> নতুন কৃষক নিবন্ধন
              </button>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-slate-800 flex flex-col md:flex-row items-center gap-5 animate-slide-up">
              <div className="flex items-center gap-4 min-w-fit px-2">
                <div className="w-12 h-12 bg-green-50 dark:bg-green-950 rounded-2xl flex items-center justify-center text-green-600 dark:text-green-400 border border-green-100 dark:border-green-900">
                  <i className="fa fa-users text-xl"></i>
                </div>
                <div>
                   <p className="text-gray-400 dark:text-slate-500 text-[9px] font-black uppercase tracking-widest whitespace-nowrap leading-none mb-1">মোট নিবন্ধিত কৃষক</p>
                   <h3 className="text-lg font-black text-gray-800 dark:text-white leading-none">{toBengaliNumber(farmers.length)} জন</h3>
                </div>
              </div>

              <div className="flex-1 w-full relative group">
                <i className="fa fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-300 dark:text-slate-600 group-focus-within:text-green-500 transition-colors"></i>
                <input 
                  type="text"
                  placeholder="মোবাইল বা এনআইডি দিয়ে খুঁজুন..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-gray-50 dark:bg-slate-950 border border-gray-100 dark:border-slate-800 rounded-2xl shadow-inner outline-none focus:ring-2 focus:ring-green-500 focus:bg-white dark:focus:bg-slate-900 transition-all placeholder:text-gray-300 dark:placeholder:text-slate-700 text-sm font-medium text-gray-800 dark:text-white"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-7 h-7 flex items-center justify-center bg-gray-200 dark:bg-slate-800 text-gray-500 dark:text-slate-400 rounded-full hover:bg-gray-300 dark:hover:bg-slate-700 transition-all"
                  >
                    <i className="fa fa-times text-[10px]"></i>
                  </button>
                )}
              </div>
            </div>

            <FarmerList 
              farmers={filteredFarmers} 
              onEdit={(f) => { setEditingFarmer(f); setView('FORM'); }} 
              onDelete={deleteFarmer} 
              onViewDetails={(f) => { setEditingFarmer(f); setView('DETAILS'); }}
            />
            
            {filteredFarmers.length === 0 && searchQuery && (
              <div className="text-center py-20 bg-white dark:bg-slate-900 rounded-[2.5rem] border-2 border-dashed border-gray-100 dark:border-slate-800">
                <i className="fa fa-search text-5xl text-gray-100 dark:text-slate-800 mb-4"></i>
                <p className="text-gray-400 dark:text-slate-500 font-bold text-lg">আপনার খোঁজা তথ্যের সাথে কোনো মিল পাওয়া যায়নি</p>
                <button onClick={() => setSearchQuery('')} className="mt-3 text-green-600 font-bold hover:underline">সার্চ পরিষ্কার করুন</button>
              </div>
            )}
          </div>
        )}

        {view === 'DETAILS' && editingFarmer && (
          <FarmerDetails 
            farmer={editingFarmer} 
            onBack={() => setView('LIST')} 
            onEdit={() => setView('FORM')} 
          />
        )}

        {view === 'FORM' && (
          <FarmerForm 
            onSubmit={addOrUpdateFarmer} 
            initialData={editingFarmer} 
            onCancel={() => setView('LIST')} 
            existingFarmers={farmers}
          />
        )}

        {view === 'PROFILE' && (
          <UserProfile 
            user={currentUser!} 
            setUser={(u: any) => { 
              const updated = typeof u === 'function' ? u(currentUser) : u;
              setCurrentUser(updated); 
              localStorage.setItem('agro_user', JSON.stringify(updated));
              
              const savedRegistrations = localStorage.getItem('agro_registered_users_list');
              if (savedRegistrations) {
                const users = JSON.parse(savedRegistrations);
                const userIndex = users.findIndex((user: any) => user.mobile === updated.id);
                if (userIndex > -1) {
                   users[userIndex] = { ...users[userIndex], ...updated, name: updated.nameBangla || updated.name };
                   localStorage.setItem('agro_registered_users_list', JSON.stringify(users));
                }
              }
            }} 
            onLogout={handleLogout} 
          />
        )}
      </main>
    </div>
  );
};

export default App;
