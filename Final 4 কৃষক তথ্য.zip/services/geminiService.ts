
import { GoogleGenAI } from "@google/genai";
import { Farmer } from "../types";

export const getFarmingInsights = async (farmers: Farmer[]) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    
    // Group farmers by village for context
    const villageStats = farmers.reduce((acc: any, f) => {
      acc[f.village] = (acc[f.village] || 0) + 1;
      return acc;
    }, {});

    const context = `We have ${farmers.length} farmers across villages: ${Object.keys(villageStats).join(', ')}.`;
    const prompt = `
      Act as an expert agricultural consultant for the Bangladesh region. 
      Based on this summary data: "${context}", provide 3 brief, high-value bullet points of advice in Bengali 
      related to irrigation, seasonal crops, or government subsidies applicable to this scale. 
      Keep it professional and encouraging.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return "বর্তমানে তথ্য বিশ্লেষণ করা সম্ভব হচ্ছে না। অনুগ্রহ করে পরে চেষ্টা করুন।";
  }
};
