
import React from 'react';
import { Farmer } from '../types';

interface StatsProps {
  farmers: Farmer[];
}

export const StatsCards: React.FC<StatsProps> = ({ farmers }) => {
  const totalFarmers = farmers.length;
  const uniqueVillages = new Set(farmers.map(f => f.village)).size;
  const recentAdds = farmers.filter(f => {
    // added fallback check for dateAdded
    const dateStr = f.dateAdded || (isNaN(Number(f.id)) ? null : new Date(Number(f.id)).toISOString());
    if (!dateStr) return false;

    const date = new Date(dateStr);
    const today = new Date();
    return (today.getTime() - date.getTime()) < (7 * 24 * 60 * 60 * 1000);
  }).length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      <div className="bg-white p-4 rounded-xl shadow-sm border-l-4 border-green-500 flex items-center space-x-4">
        <div className="bg-green-100 p-3 rounded-full">
          <i className="fas fa-users text-green-600 text-xl"></i>
        </div>
        <div>
          <p className="text-gray-500 text-sm">মোট কৃষক</p>
          <p className="text-2xl font-bold text-gray-800">{totalFarmers}</p>
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-xl shadow-sm border-l-4 border-blue-500 flex items-center space-x-4">
        <div className="bg-blue-100 p-3 rounded-full">
          <i className="fas fa-map-marker-alt text-blue-600 text-xl"></i>
        </div>
        <div>
          <p className="text-gray-500 text-sm">মোট গ্রাম</p>
          <p className="text-2xl font-bold text-gray-800">{uniqueVillages}</p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border-l-4 border-orange-500 flex items-center space-x-4">
        <div className="bg-orange-100 p-3 rounded-full">
          <i className="fas fa-calendar-plus text-orange-600 text-xl"></i>
        </div>
        <div>
          <p className="text-gray-500 text-sm">এই সপ্তাহে নতুন</p>
          <p className="text-2xl font-bold text-gray-800">{recentAdds}</p>
        </div>
      </div>
    </div>
  );
};
