
import React, { useState, useRef, useMemo } from 'react';
import { Farmer, SeasonalService } from '../types';
import { BD_HIERARCHY, toBengaliNumber } from '../constants';

interface FarmerFormProps {
  onSubmit: (farmer: Farmer) => void;
  initialData: Farmer | null;
  onCancel: () => void;
  existingFarmers: Farmer[];
}

const FarmerForm: React.FC<FarmerFormProps> = ({ onSubmit, initialData, onCancel, existingFarmers }) => {
  const [formData, setFormData] = useState<Farmer>(initialData || {
    id: '', photo: null, name: '', nameBangla: '', fatherHusbandName: '', fatherHusbandNameBangla: '',
    motherName: '', motherNameBangla: '', dob: '', bloodGroup: '', division: 'ময়মনসিংহ বিভাগ',
    district: '', upazila: '', union: '', village: '', postOffice: '', postCode: '',
    ward: '', block: '', mobile: '', nid: '', seasonalServices: [], services: '',
    dateAdded: ''
  });

  const [tempService, setTempService] = useState({ fiscalYear: '', season: '', crop: '', count: '', type: '' });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const divisions = useMemo(() => Object.keys(BD_HIERARCHY), []);
  const districts = useMemo(() => 
    formData.division ? Object.keys(BD_HIERARCHY[formData.division] || {}) : [], 
  [formData.division]);
  
  const upazilas = useMemo(() => 
    (formData.division && formData.district) ? Object.keys(BD_HIERARCHY[formData.division]?.[formData.district] || {}) : [], 
  [formData.division, formData.district]);

  const unions = useMemo(() => 
    (formData.division && formData.district && formData.upazila) ? 
    BD_HIERARCHY[formData.division]?.[formData.district]?.[formData.upazila] || [] : [], 
  [formData.division, formData.district, formData.upazila]);

  const crops = ['বোরো ধান', 'আমন ধান', 'আউশ ধান', 'গম', 'ভুট্টা', 'আলু', 'সরিষা', 'পেঁয়াজ', 'রসুন', 'মরিচ', 'পাট', 'শাক-সবজি', 'আম', 'লিচু', 'অন্যান্য'];
  const serviceCounts = ['১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '১০+'];
  const serviceTypes = ['প্রণোদনা', 'প্রদর্শনী'];
  const wards = ['১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  
  const fiscalYears = useMemo(() => {
    const years = [];
    for (let i = 2024; i <= 2050; i++) {
      years.push(`${i}-${i + 1}`);
    }
    return years;
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    let finalValue = value;
    
    if (name === 'mobile' || name === 'nid' || name === 'postCode') {
        finalValue = value.replace(/[^0-9]/g, '');
    }

    setFormData(prev => {
      const newState = { ...prev, [name]: finalValue };
      if (name === 'division') {
        newState.district = ''; newState.upazila = ''; newState.union = '';
      } else if (name === 'district') {
        newState.upazila = ''; newState.union = '';
      } else if (name === 'upazila') {
        newState.union = '';
      }
      return newState;
    });
  };

  const handlePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setFormData(prev => ({ ...prev, photo: reader.result as string }));
      reader.readAsDataURL(file);
    }
  };

  const addService = () => {
    if (!tempService.fiscalYear || !tempService.season || !tempService.crop || !tempService.count || !tempService.type) {
      alert('অনুগ্রহ করে অর্থ বছর, মৌসুম, ফসল, সেবা সংখ্যা এবং সেবার ধরন নির্বাচন করুন।');
      return;
    }
    const newService: SeasonalService = { 
      season: `${tempService.fiscalYear} (${tempService.season})`, 
      crop: tempService.crop, 
      serviceCount: tempService.count,
      serviceType: tempService.type
    };
    setFormData(prev => ({ ...prev, seasonalServices: [...prev.seasonalServices, newService] }));
    setTempService({ fiscalYear: '', season: '', crop: '', count: '', type: '' });
  };

  const editServiceEntry = (idx: number) => {
    const service = formData.seasonalServices[idx];
    const match = service.season.match(/(.*) \((.*)\)/);
    if (match) {
      setTempService({
        fiscalYear: match[1],
        season: match[2],
        crop: service.crop,
        count: service.serviceCount,
        type: service.serviceType || ''
      });
      setFormData(prev => ({
        ...prev,
        seasonalServices: prev.seasonalServices.filter((_, i) => i !== idx)
      }));
    }
  };

  const validateAndSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.mobile.length !== 11) { alert('সঠিক ১১ সংখ্যার মোবাইল নাম্বার দিন।'); return; }
    if (formData.nid.length < 10) { alert('সঠিক এনআইডি নাম্বার প্রদান করুন।'); return; }
    onSubmit(formData);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xl p-6 md:p-8 space-y-8 animate-slide-up border border-gray-100 dark:border-slate-800 max-w-5xl mx-auto">
      <div className="flex items-center justify-between border-b dark:border-slate-800 pb-6">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white">{initialData ? 'তথ্য সংশোধন' : 'নতুন কৃষক নিবন্ধন'}</h2>
        <button onClick={onCancel} className="w-10 h-10 rounded-full bg-gray-50 dark:bg-slate-800 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-all">
          <i className="fa fa-times"></i>
        </button>
      </div>

      <form onSubmit={validateAndSubmit} className="space-y-8">
        <div className="flex flex-col items-center gap-4">
          <div 
            className="w-32 h-32 rounded-3xl bg-gray-50 dark:bg-slate-950 border-4 border-white dark:border-slate-800 shadow-lg overflow-hidden flex items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-800 transition-all group" 
            onClick={() => fileInputRef.current?.click()}
          >
            {formData.photo ? (
              <img src={formData.photo} className="w-full h-full object-cover" alt="Farmer" />
            ) : (
              <div className="text-center">
                <i className="fa fa-camera text-4xl text-gray-200 dark:text-slate-800 group-hover:text-green-400 transition-colors"></i>
                <p className="text-[10px] text-gray-300 dark:text-slate-700 mt-1 font-bold">আপলোড</p>
              </div>
            )}
          </div>
          <input type="file" ref={fileInputRef} className="hidden" onChange={handlePhoto} accept="image/*" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h4 className="font-bold text-xs uppercase tracking-widest text-green-600 border-l-4 border-green-600 pl-3 mb-6">ব্যক্তিগত তথ্য</h4>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <input name="nameBangla" placeholder="নাম (বাংলা)" value={formData.nameBangla} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none focus:ring-2 focus:ring-green-500 transition-all" required />
                <input name="name" placeholder="Name (English)" value={formData.name} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none focus:ring-2 focus:ring-green-500 transition-all" required />
              </div>
              <input name="fatherHusbandNameBangla" placeholder="পিতা/স্বামীর নাম (বাংলা)" value={formData.fatherHusbandNameBangla} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none focus:ring-2 focus:ring-green-500 transition-all" required />
              <input name="motherNameBangla" placeholder="মাতার নাম (বাংলা)" value={formData.motherNameBangla} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none focus:ring-2 focus:ring-green-500 transition-all" required />
              <div className="grid grid-cols-2 gap-3">
                <input name="nid" type="tel" placeholder="এনআইডি নাম্বার" value={formData.nid} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none focus:ring-2 focus:ring-green-500 transition-all" required />
                <input name="mobile" type="tel" placeholder="মোবাইল নাম্বার" value={formData.mobile} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none focus:ring-2 focus:ring-green-500 font-bold" maxLength={11} required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="relative">
                    <label className="absolute -top-2 left-3 bg-white dark:bg-slate-900 px-1 text-[10px] text-gray-400 font-bold">জন্ম তারিখ</label>
                    <input type="date" name="dob" value={formData.dob} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none focus:ring-2 focus:ring-green-500 transition-all" required />
                </div>
                <select name="bloodGroup" value={formData.bloodGroup} onChange={handleChange} className="p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none text-sm font-medium">
                  <option value="">রক্তের গ্রুপ</option>
                  {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => <option key={bg} value={bg}>{bg}</option>)}
                </select>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <h4 className="font-bold text-xs uppercase tracking-widest text-green-600 border-l-4 border-green-600 pl-3 mb-6">ঠিকানা ও যোগাযোগ</h4>
            <div className="grid grid-cols-2 gap-3">
              <select name="division" value={formData.division} onChange={handleChange} className="p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none text-sm font-medium">
                {divisions.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
              <select name="district" value={formData.district} onChange={handleChange} className="p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none text-sm font-medium">
                <option value="">জেলা</option>
                {districts.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
              <select name="upazila" value={formData.upazila} onChange={handleChange} className="p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none text-sm font-medium">
                <option value="">উপজেলা</option>
                {upazilas.map(u => <option key={u} value={u}>{u}</option>)}
              </select>
              <div className="relative">
                {unions.length > 0 ? (
                  <select name="union" value={formData.union} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none text-sm font-medium">
                    <option value="">ইউনিয়ন</option>
                    {unions.map(u => <option key={u} value={u}>{u}</option>)}
                  </select>
                ) : (
                  <input name="union" placeholder="ইউনিয়ন" value={formData.union} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none text-sm" />
                )}
              </div>
              <input name="village" placeholder="গ্রাম/পাড়া" value={formData.village} onChange={handleChange} className="p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none text-sm" />
              <select name="ward" value={formData.ward} onChange={handleChange} className="p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none text-sm font-medium">
                <option value="">ওয়ার্ড নং</option>
                {wards.map(w => <option key={w} value={w}>{toBengaliNumber(w)}</option>)}
              </select>
              <div className="col-span-2 grid grid-cols-2 gap-3">
                 <input name="postOffice" placeholder="ডাকঘর" value={formData.postOffice} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none text-sm focus:ring-2 focus:ring-green-500 transition-all" />
                 <input name="postCode" type="tel" placeholder="পোস্ট কোড" value={formData.postCode} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-slate-950 text-gray-800 dark:text-white rounded-2xl border-none outline-none text-sm focus:ring-2 focus:ring-green-500 transition-all" maxLength={5} />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-green-50/50 dark:bg-green-950/20 p-6 md:p-8 rounded-[2.5rem] space-y-6 border border-green-100 dark:border-green-900/50">
          <div className="flex items-center gap-3">
             <div className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center text-xs"><i className="fa fa-layer-group"></i></div>
             <h4 className="font-bold text-sm uppercase tracking-wider text-green-800 dark:text-green-400">সেবা প্রাপ্তির বিবরণ</h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
            <div>
              <label className="text-[10px] font-bold text-green-600 dark:text-green-500 uppercase mb-1 block">অর্থ বছর</label>
              <select value={tempService.fiscalYear} onChange={e => setTempService({...tempService, fiscalYear: e.target.value})} className="w-full p-3 rounded-xl border-none outline-none text-sm font-medium bg-white dark:bg-slate-900 text-gray-800 dark:text-white shadow-sm">
                <option value="">নির্বাচন</option>
                {fiscalYears.map(fy => <option key={fy} value={fy}>{toBengaliNumber(fy)}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-bold text-green-600 dark:text-green-500 uppercase mb-1 block">মৌসুম</label>
              <select value={tempService.season} onChange={e => setTempService({...tempService, season: e.target.value})} className="w-full p-3 rounded-xl border-none outline-none text-sm font-medium bg-white dark:bg-slate-900 text-gray-800 dark:text-white shadow-sm">
                <option value="">নির্বাচন</option>
                <option value="রবি">রবি</option>
                <option value="খরিপ-১">খরিপ-১</option>
                <option value="খরিপ-২">খরিপ-২</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] font-bold text-green-600 dark:text-green-500 uppercase mb-1 block">ফসল</label>
              <select value={tempService.crop} onChange={e => setTempService({...tempService, crop: e.target.value})} className="w-full p-3 rounded-xl border-none outline-none text-sm font-medium bg-white dark:bg-slate-900 text-gray-800 dark:text-white shadow-sm">
                <option value="">নির্বাচন</option>
                {crops.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-bold text-green-600 dark:text-green-500 uppercase mb-1 block">সেবা সংখ্যা</label>
              <select value={tempService.count} onChange={e => setTempService({...tempService, count: e.target.value})} className="w-full p-3 rounded-xl border-none outline-none text-sm font-medium bg-white dark:bg-slate-900 text-gray-800 dark:text-white shadow-sm">
                <option value="">নির্বাচন</option>
                {serviceCounts.map(count => <option key={count} value={count}>{toBengaliNumber(count)} বার</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-bold text-green-600 dark:text-green-500 uppercase mb-1 block">সেবা ধরন</label>
              <select value={tempService.type} onChange={e => setTempService({...tempService, type: e.target.value})} className="w-full p-3 rounded-xl border-none outline-none text-sm font-black bg-white dark:bg-slate-900 text-green-700 dark:text-green-400 shadow-sm">
                <option value="">নির্বাচন</option>
                {serviceTypes.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="flex items-end">
              <button type="button" onClick={addService} className="w-full bg-green-600 text-white font-bold rounded-xl py-3 hover:bg-green-700 transition-all active:scale-95 shadow-lg shadow-green-200 dark:shadow-none flex items-center justify-center gap-2">
                <i className="fa fa-plus-circle"></i> যোগ
              </button>
            </div>
          </div>
          
          <div className="space-y-3 mt-6">
            {formData.seasonalServices.length > 0 ? (
              <div className="grid grid-cols-1 gap-3">
                {formData.seasonalServices.map((s, i) => (
                  <div key={i} className="bg-white dark:bg-slate-900 p-4 rounded-2xl flex justify-between items-center shadow-sm border border-green-50 dark:border-green-900/30 hover:border-green-200 dark:hover:border-green-700 transition-all animate-slide-up">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-2xl bg-green-50 dark:bg-green-950 text-green-600 dark:text-green-400 flex items-center justify-center font-bold text-sm">{toBengaliNumber(i + 1)}</div>
                      <div>
                        <p className="text-[9px] text-gray-400 dark:text-slate-500 font-black uppercase tracking-widest">{toBengaliNumber(s.season)}</p>
                        <p className="text-sm font-bold text-gray-800 dark:text-slate-100">{s.crop} <span className="mx-2 text-gray-300 dark:text-slate-800">|</span> <span className="text-green-600 dark:text-green-400 font-black">{s.serviceType}</span></p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="hidden sm:inline-block px-4 py-1.5 bg-green-50 dark:bg-green-950/40 text-green-700 dark:text-green-400 rounded-full font-bold text-xs">{toBengaliNumber(s.serviceCount)} বার সেবা</span>
                      
                      <div className="flex gap-2">
                        <button 
                          type="button" 
                          onClick={() => editServiceEntry(i)} 
                          className="w-10 h-10 flex items-center justify-center bg-blue-50 dark:bg-blue-950/30 text-blue-500 dark:text-blue-400 rounded-xl hover:bg-blue-600 hover:text-white transition-all shadow-sm"
                          title="এডিট করুন"
                        >
                          <i className="fa fa-pencil-alt"></i>
                        </button>
                        <button 
                          type="button" 
                          onClick={() => setFormData({...formData, seasonalServices: formData.seasonalServices.filter((_, idx) => idx !== i)})} 
                          className="w-10 h-10 flex items-center justify-center bg-red-50 dark:bg-red-950/30 text-red-400 dark:text-red-400 rounded-xl hover:bg-red-500 hover:text-white transition-all shadow-sm"
                          title="মুছে ফেলুন"
                        >
                          <i className="fa fa-trash-alt"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 bg-white/50 dark:bg-slate-900/50 rounded-3xl border border-dashed border-green-200 dark:border-green-900/50">
                <i className="fa fa-clipboard-list text-3xl text-green-100 dark:text-green-900/30 mb-2"></i>
                <p className="text-gray-400 dark:text-slate-600 text-xs font-medium">এখন পর্যন্ত কোনো সেবা যুক্ত করা হয়নি</p>
              </div>
            )}
          </div>
        </div>

        <div className="flex gap-4 pt-6">
          <button type="submit" className="flex-1 bg-green-600 text-white py-5 rounded-[2rem] font-bold shadow-xl shadow-green-100 dark:shadow-none hover:bg-green-700 transition-all active:scale-[0.98] flex items-center justify-center gap-3 text-lg"><i className="fa fa-check-circle"></i> তথ্য সংরক্ষণ করুন</button>
          <button type="button" onClick={onCancel} className="px-10 bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-slate-400 py-5 rounded-[2rem] font-bold hover:bg-gray-200 dark:hover:bg-slate-700 transition-all text-lg">বাতিল</button>
        </div>
      </form>
    </div>
  );
};

export default FarmerForm;
