
import React from 'react';
import { Farmer } from '../types';
import { toBengaliNumber } from '../constants';

interface FarmerDetailsProps {
  farmer: Farmer;
  onBack: () => void;
  onEdit: () => void;
}

const FarmerDetails: React.FC<FarmerDetailsProps> = ({ farmer, onBack, onEdit }) => {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xl overflow-hidden animate-slide-up border border-gray-100 dark:border-slate-800 max-w-4xl mx-auto mb-10">
      {/* Header Banner */}
      <div className="h-32 bg-gradient-to-r from-green-600 to-emerald-700 relative">
        <button 
          onClick={onBack}
          className="absolute top-6 left-6 w-10 h-10 bg-white/20 hover:bg-white/40 text-white rounded-full flex items-center justify-center backdrop-blur-md transition-all"
        >
          <i className="fa fa-arrow-left"></i>
        </button>
        <button 
          onClick={onEdit}
          className="absolute top-6 right-6 px-5 py-2 bg-white dark:bg-slate-800 text-green-700 dark:text-green-400 rounded-xl font-bold shadow-lg hover:bg-green-50 dark:hover:bg-slate-700 transition-all text-sm"
        >
          <i className="fa fa-edit mr-2"></i> তথ্য সংশোধন
        </button>
      </div>

      <div className="px-6 md:px-10 pb-10">
        <div className="relative -mt-16 mb-8 flex flex-col md:flex-row items-center md:items-end gap-6">
          <img 
            src={farmer.photo || `https://ui-avatars.com/api/?name=${encodeURIComponent(farmer.name)}&background=f0fdf4&color=166534`} 
            className="w-40 h-40 rounded-3xl object-cover border-4 border-white dark:border-slate-800 shadow-2xl bg-white dark:bg-slate-950" 
            alt={farmer.nameBangla} 
          />
          <div className="text-center md:text-left pb-2">
            <h2 className="text-3xl font-bold text-gray-800 dark:text-white">{farmer.nameBangla}</h2>
            <p className="text-gray-500 dark:text-slate-400 font-medium">{farmer.name}</p>
            <div className="flex flex-wrap justify-center md:justify-start gap-3 mt-3">
              <span className="bg-green-50 dark:bg-green-950/40 text-green-700 dark:text-green-400 px-3 py-1 rounded-full text-xs font-bold border border-green-100 dark:border-green-900">
                <i className="fa fa-phone mr-1"></i> {toBengaliNumber(farmer.mobile)}
              </span>
              <span className="bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400 px-3 py-1 rounded-full text-xs font-bold border border-blue-100 dark:border-blue-900">
                <i className="fa fa-id-card mr-1"></i> এনআইডি: {toBengaliNumber(farmer.nid)}
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {/* Left Column: Personal & Address */}
          <div className="space-y-8">
            <section>
              <h3 className="text-sm font-bold text-green-700 dark:text-green-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                <i className="fa fa-user-circle"></i> ব্যক্তিগত তথ্য
              </h3>
              <div className="bg-gray-50 dark:bg-slate-950 p-5 rounded-2xl space-y-4 border border-transparent dark:border-slate-800">
                <InfoRow label="পিতা/স্বামীর নাম" value={farmer.fatherHusbandNameBangla} />
                <InfoRow label="মাতার নাম" value={farmer.motherNameBangla} />
                <InfoRow label="জন্ম তারিখ" value={toBengaliNumber(farmer.dob)} />
                <InfoRow label="রক্তের গ্রুপ" value={farmer.bloodGroup || 'অজানা'} />
              </div>
            </section>

            <section>
              <h3 className="text-sm font-bold text-green-700 dark:text-green-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                <i className="fa fa-map-marker-alt"></i> বর্তমান ঠিকানা
              </h3>
              <div className="bg-gray-50 dark:bg-slate-950 p-5 rounded-2xl space-y-4 border border-transparent dark:border-slate-800">
                <InfoRow label="বিভাগ" value={farmer.division} />
                <InfoRow label="জেলা ও উপজেলা" value={`${farmer.district}, ${farmer.upazila}`} />
                <InfoRow label="ইউনিয়ন ও ওয়ার্ড" value={`${farmer.union}, ওয়ার্ড নং ${toBengaliNumber(farmer.ward)}`} />
                <InfoRow label="গ্রাম/পাড়া" value={farmer.village} />
                <InfoRow label="ডাকঘর ও কোড" value={`${farmer.postOffice} (${toBengaliNumber(farmer.postCode)})`} />
              </div>
            </section>
          </div>

          {/* Right Column: Services History */}
          <div className="space-y-6">
            <h3 className="text-sm font-bold text-emerald-700 dark:text-emerald-500 uppercase tracking-widest flex items-center gap-2">
              <i className="fa fa-history"></i> সেবা প্রাপ্তির বিবরণ (বছর ভিত্তিক)
            </h3>
            {farmer.seasonalServices && farmer.seasonalServices.length > 0 ? (
              <div className="space-y-3">
                {farmer.seasonalServices.map((service, idx) => (
                  <div key={idx} className="bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/50 rounded-2xl p-4 flex justify-between items-center group hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-all">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 rounded-xl flex items-center justify-center font-bold text-sm">
                        {toBengaliNumber(idx + 1)}
                      </div>
                      <div>
                        <p className="text-[10px] text-emerald-600 dark:text-emerald-500 font-bold uppercase tracking-tighter">{toBengaliNumber(service.season)}</p>
                        <p className="text-sm font-bold text-gray-800 dark:text-slate-100">
                          {service.crop} 
                          {service.serviceType && <span className="ml-2 px-2 py-0.5 bg-white dark:bg-slate-900 rounded text-[10px] text-green-700 dark:text-green-400 border border-green-100 dark:border-green-900 font-black">{service.serviceType}</span>}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-gray-400 dark:text-slate-500 font-bold uppercase mb-1">সেবা সংখ্যা</p>
                      <span className="bg-emerald-600 text-white px-3 py-1 rounded-lg font-bold text-xs">
                        {toBengaliNumber(service.serviceCount)} বার
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-gray-50 dark:bg-slate-950 rounded-2xl p-10 text-center border border-dashed border-gray-200 dark:border-slate-800">
                <i className="fa fa-clipboard-list text-3xl text-gray-200 dark:text-slate-800 mb-2"></i>
                <p className="text-gray-400 dark:text-slate-600 text-xs font-medium">কোনো সেবার তথ্য সংরক্ষিত নেই</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const InfoRow = ({ label, value }: { label: string; value: string }) => (
  <div className="flex justify-between items-center border-b border-gray-100 dark:border-slate-800 pb-2 last:border-0 last:pb-0">
    <span className="text-xs text-gray-400 dark:text-slate-500 font-medium">{label}</span>
    <span className="text-sm font-bold text-gray-700 dark:text-slate-200">{value}</span>
  </div>
);

export default FarmerDetails;
