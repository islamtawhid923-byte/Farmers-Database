
import React, { useState, useEffect, useRef } from 'react';

interface LoginProps {
  onLogin: (id: string, pass: string) => void;
  onGoToRegister: () => void;
}

type ForgotStep = 'MOBILE' | 'OTP' | 'NEW_PASS';

const Login: React.FC<LoginProps> = ({ onLogin, onGoToRegister }) => {
  const [id, setId] = useState('');
  const [pass, setPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmNewPass, setConfirmNewPass] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [isForgotMode, setIsForgotMode] = useState(false);
  const [forgotStep, setForgotStep] = useState<ForgotStep>('MOBILE');
  const [successMsg, setSuccessMsg] = useState('');
  
  const [otp, setOtp] = useState(['', '', '', '']);
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [showOtpPopup, setShowOtpPopup] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Timer for OTP
  useEffect(() => {
    if (forgotStep === 'OTP' && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [forgotStep, timeLeft]);

  const generateOtp = () => {
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(code);
    return code;
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const savedRegistrations = localStorage.getItem('agro_registered_users_list');
    const users = savedRegistrations ? JSON.parse(savedRegistrations) : [];
    
    const foundUser = users.find((u: any) => u.mobile === id && u.password === pass);
    if (foundUser) {
      onLogin(id, pass);
    } else {
      setError('মোবাইল নম্বর বা পাসওয়ার্ড সঠিক নয়। দয়া করে পুনরায় চেষ্টা করুন।');
    }
  };

  const handleForgotMobileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!id) {
      alert('অনুগ্রহ করে মোবাইল নম্বরটি দিন।');
      return;
    }

    const savedRegistrations = localStorage.getItem('agro_registered_users_list');
    const users = savedRegistrations ? JSON.parse(savedRegistrations) : [];
    const userExists = users.some((u: any) => u.mobile === id);

    if (userExists) {
      generateOtp();
      setShowOtpPopup(true);
    } else {
      alert('নাম্বার টি সঠিক নয়। এই নম্বরটি আমাদের সিস্টেমে নিবন্ধিত নেই।');
    }
  };

  const startOtpVerification = () => {
    setShowOtpPopup(false);
    setForgotStep('OTP');
    setTimeLeft(120);
    setOtp(['', '', '', '']);
  };

  const handleOtpChange = (index: number, value: string) => {
    const val = value.replace(/[^0-9]/g, '');
    const newOtp = [...otp];
    newOtp[index] = val.slice(-1);
    setOtp(newOtp);
    if (val && index < 3) {
      const nextInput = document.getElementById(`forgot-otp-${index + 1}`);
      if (nextInput) (nextInput as HTMLInputElement).focus();
    }
  };

  const verifyOtp = () => {
    if (timeLeft === 0) {
      alert('ওটিপি কোডটির মেয়াদ শেষ হয়ে গেছে।');
      return;
    }
    if (otp.join('') === generatedOtp) {
      setForgotStep('NEW_PASS');
      setError('');
    } else {
      alert('ভুল ওটিপি কোড!');
    }
  };

  const handlePasswordReset = (e: React.FormEvent) => {
    e.preventDefault();
    // STRICT 4 DIGIT PASSWORD CHECK
    if (newPass.length !== 4) {
      setError('পাসওয়ার্ড ঠিক ৪ সংখ্যার হতে হবে।');
      return;
    }
    if (newPass !== confirmNewPass) {
      setError('পাসওয়ার্ড দুটি মিলছে না।');
      return;
    }

    const savedRegistrations = localStorage.getItem('agro_registered_users_list');
    const users = savedRegistrations ? JSON.parse(savedRegistrations) : [];
    const userIndex = users.findIndex((u: any) => u.mobile === id);

    if (userIndex > -1) {
      users[userIndex].password = newPass;
      localStorage.setItem('agro_registered_users_list', JSON.stringify(users));
      setSuccessMsg('পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে।');
      setTimeout(() => {
        toggleBackToLogin();
      }, 2000);
    } else {
      setError('সিস্টেমে কোনো সমস্যা হয়েছে। পুনরায় চেষ্টা করুন।');
    }
  };

  const toggleBackToLogin = () => {
    setIsForgotMode(false);
    setForgotStep('MOBILE');
    setError('');
    setSuccessMsg('');
    setPass('');
    setNewPass('');
    setConfirmNewPass('');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-emerald-100 dark:from-slate-900 dark:to-slate-950 p-4 relative overflow-hidden font-['Hind_Siliguri'] transition-colors duration-500">
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-white/50 dark:bg-green-900/10 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2 z-0"></div>

      {/* OTP Popup Simulation */}
      {showOtpPopup && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-10 max-w-sm w-full shadow-2xl text-center space-y-6 animate-slide-up border border-white dark:border-slate-800">
            <div className="w-20 h-20 bg-green-50 dark:bg-green-950 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto ring-4 ring-green-50 dark:ring-green-900/20">
              <i className="fa-solid fa-fire-flame-curved text-3xl"></i>
            </div>
            <div>
              <h3 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight leading-none">ফায়ারবেস ভেরিফিকেশন</h3>
              <p className="text-gray-400 dark:text-slate-500 text-[10px] font-black uppercase tracking-widest mt-2">আপনার পাসওয়ার্ড রিসেট কোড</p>
            </div>
            <div className="bg-slate-50 dark:bg-slate-950 py-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-inner">
               <span className="text-5xl font-black text-green-600 dark:text-green-400 tracking-[0.2em] font-mono pl-3">{generatedOtp}</span>
            </div>
            <button 
              onClick={startOtpVerification} 
              className="w-full bg-gray-900 dark:bg-green-600 hover:bg-green-600 dark:hover:bg-green-700 text-white py-5 rounded-2xl font-black transition-all active:scale-95 shadow-lg"
            >
              কোডটি যাচাই করুন
            </button>
          </div>
        </div>
      )}
      
      <div className="w-full max-md bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl rounded-[3rem] shadow-[0_32px_80px_-16px_rgba(0,0,0,0.1)] p-10 space-y-8 animate-slide-up relative z-10 border border-white dark:border-slate-800">
        <div className="text-center space-y-4">
          <div className="bg-gradient-to-br from-green-500 to-emerald-600 w-20 h-20 rounded-[2rem] flex items-center justify-center mx-auto shadow-xl transition-transform duration-500 hover:rotate-12">
            <i className={`fa ${isForgotMode ? 'fa-key' : 'fa-leaf'} text-4xl text-white`}></i>
          </div>
          <div>
            <h1 className="text-3xl font-black text-gray-900 dark:text-white tracking-tight leading-none">
              {isForgotMode ? (forgotStep === 'NEW_PASS' ? 'নতুন পাসওয়ার্ড' : 'পাসওয়ার্ড রিসেট') : 'স্বাগতম'}
            </h1>
            <p className="text-green-600 dark:text-green-400 mt-2 font-bold text-[10px] tracking-[0.2em] uppercase opacity-70">কৃষক তথ্য ব্যবস্থাপনা</p>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 text-red-500 p-4 rounded-2xl text-[10px] font-black text-center border border-red-100 dark:border-red-900/30 animate-fade-in">
            <i className="fa fa-circle-exclamation mr-2"></i> {error}
          </div>
        )}

        {successMsg && (
          <div className="bg-green-50 dark:bg-green-900/20 text-green-600 p-4 rounded-2xl text-[10px] font-black text-center border border-green-100 dark:border-green-900/30 animate-fade-in">
            <i className="fa fa-circle-check mr-2"></i> {successMsg}
          </div>
        )}

        {!isForgotMode ? (
          /* LOGIN FORM */
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div className="relative group">
              <i className="fa fa-user absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 dark:text-slate-600 group-focus-within:text-green-500 transition-colors"></i>
              <input 
                type="tel" 
                className="w-full pl-16 pr-6 py-5 bg-gray-50/50 dark:bg-slate-950/50 border-2 border-transparent rounded-2xl focus:border-green-500 dark:focus:border-green-600 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all font-black text-gray-800 dark:text-white tracking-wide"
                placeholder="মোবাইল নম্বর"
                value={id}
                onChange={(e) => setId(e.target.value.replace(/[^0-9]/g, ''))}
                required
              />
            </div>

            <div className="relative group">
              <i className="fa fa-lock absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 dark:text-slate-600 group-focus-within:text-green-500 transition-colors"></i>
              <input 
                type={showPass ? "text" : "password"} 
                className="w-full pl-16 pr-14 py-5 bg-gray-50/50 dark:bg-slate-950/50 border-2 border-transparent rounded-2xl focus:border-green-500 dark:focus:border-green-600 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all font-black text-gray-800 dark:text-white"
                placeholder="****"
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                required
              />
              <button 
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-200 hover:text-green-600"
              >
                <i className={`fa ${showPass ? 'fa-eye-slash' : 'fa-eye'} text-xs`}></i>
              </button>
            </div>

            <div className="flex justify-end px-2">
              <button 
                type="button" 
                onClick={() => setIsForgotMode(true)} 
                className="text-[9px] text-gray-300 dark:text-slate-600 font-black uppercase hover:text-green-600 dark:hover:text-green-400 transition-colors tracking-widest"
              >
                ভুলে গেছেন?
              </button>
            </div>

            <button 
              type="submit" 
              className="w-full bg-gray-900 dark:bg-green-600 hover:bg-green-600 dark:hover:bg-green-700 text-white font-black py-6 rounded-3xl shadow-2xl transition-all transform active:scale-[0.98] text-lg"
            >
              লগইন করুন
            </button>
          </form>
        ) : (
          /* FORGOT PASSWORD FLOW */
          <div className="animate-slide-up">
            {forgotStep === 'MOBILE' && (
              <form onSubmit={handleForgotMobileSubmit} className="space-y-6">
                <div className="relative group">
                  <i className="fa fa-phone-volume absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 dark:text-slate-600 group-focus-within:text-green-500 transition-colors"></i>
                  <input 
                    type="tel" 
                    className="w-full pl-16 pr-6 py-5 bg-gray-50/50 dark:bg-slate-950/50 border-2 border-transparent rounded-2xl focus:border-green-500 dark:focus:border-green-600 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all font-black text-gray-800 dark:text-white tracking-wide"
                    placeholder="নিবন্ধিত মোবাইল নম্বর"
                    value={id}
                    onChange={(e) => setId(e.target.value.replace(/[^0-9]/g, ''))}
                    required
                  />
                </div>
                <button 
                  type="submit" 
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-black py-5 rounded-2xl shadow-xl transition-all active:scale-95"
                >
                  ওটিপি পাঠান
                </button>
              </form>
            )}

            {forgotStep === 'OTP' && (
              <div className="space-y-8 text-center">
                <p className="text-gray-500 dark:text-slate-400 text-xs font-bold px-4">আপনার নম্বরে পাঠানো ৪ সংখ্যার কোডটি দিন</p>
                <div className="flex justify-center gap-3">
                  {otp.map((d, i) => (
                    <input 
                      key={i} 
                      id={`forgot-otp-${i}`} 
                      type="text" 
                      value={d} 
                      onChange={e => handleOtpChange(i, e.target.value)} 
                      className="w-14 h-16 text-center text-3xl font-black border-2 border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 text-gray-800 dark:text-white rounded-2xl focus:border-green-600 outline-none transition-all shadow-sm" 
                      maxLength={1}
                    />
                  ))}
                </div>
                <div className="flex flex-col gap-4">
                  <button 
                    onClick={verifyOtp} 
                    className="w-full bg-green-600 hover:bg-green-700 text-white py-5 rounded-2xl font-black shadow-lg"
                  >
                    যাচাই সম্পন্ন করুন
                  </button>
                  <p className="text-[10px] font-black text-gray-400 dark:text-slate-500">
                    সময় বাকি: <span className={timeLeft < 30 ? 'text-red-500' : 'text-green-600'}>{Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}</span>
                  </p>
                </div>
              </div>
            )}

            {forgotStep === 'NEW_PASS' && (
              <form onSubmit={handlePasswordReset} className="space-y-4">
                <div className="space-y-4">
                  <div className="relative group">
                    <i className="fa fa-lock-open absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 dark:text-slate-600 group-focus-within:text-green-500 transition-colors"></i>
                    <input 
                      type="password" 
                      className="w-full pl-16 pr-6 py-5 bg-gray-50/50 dark:bg-slate-950/50 border-2 border-transparent rounded-2xl focus:border-green-500 dark:focus:border-green-600 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all font-black text-gray-800 dark:text-white"
                      placeholder="নতুন পাসওয়ার্ড (৪ সংখ্যা)"
                      value={newPass}
                      onChange={(e) => setNewPass(e.target.value.replace(/[^0-9]/g, '').slice(0,4))}
                      maxLength={4}
                      required
                    />
                  </div>
                  <div className="relative group">
                    <i className="fa fa-shield-check absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 dark:text-slate-600 group-focus-within:text-green-500 transition-colors"></i>
                    <input 
                      type="password" 
                      className="w-full pl-16 pr-6 py-5 bg-gray-50/50 dark:bg-slate-950/50 border-2 border-transparent rounded-2xl focus:border-green-500 dark:focus:border-green-600 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all font-black text-gray-800 dark:text-white"
                      placeholder="পাসওয়ার্ড নিশ্চিত করুন"
                      value={confirmNewPass}
                      onChange={(e) => setConfirmNewPass(e.target.value.replace(/[^0-9]/g, '').slice(0,4))}
                      maxLength={4}
                      required
                    />
                  </div>
                </div>
                <button 
                  type="submit" 
                  className="w-full bg-gray-900 dark:bg-green-600 hover:bg-green-600 dark:hover:bg-green-700 text-white font-black py-5 rounded-2xl shadow-xl transition-all"
                >
                  পাসওয়ার্ড আপডেট করুন
                </button>
              </form>
            )}
          </div>
        )}
        
        <div className="text-center">
          {isForgotMode ? (
            <button 
              onClick={toggleBackToLogin} 
              className="text-green-600 dark:text-green-400 font-black text-[11px] uppercase tracking-widest hover:underline"
            >
              <i className="fa-solid fa-arrow-left mr-2"></i> লগইন ফিরে যান
            </button>
          ) : (
            <p className="text-gray-400 dark:text-slate-500 text-[11px] font-medium uppercase tracking-widest">
              অ্যাকাউন্ট নেই? <button onClick={onGoToRegister} className="text-green-600 dark:text-green-400 font-black hover:underline ml-1">নিবন্ধন করুন</button>
            </p>
          )}
        </div>

        <div className="text-center pt-2 opacity-30">
          <p className="text-[8px] font-black text-gray-400 dark:text-slate-600 uppercase tracking-[0.2em]">© ২০২৬ সিস্টেম ডিজাইন ও ডেভলোপমেন্ট মির্জা মোঃ তাওহিদুল ইসলাম</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
