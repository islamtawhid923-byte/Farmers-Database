
import React from 'react';
import { Farmer } from '../types';
import { toBengaliNumber } from '../constants';

interface FarmerListProps {
  farmers: Farmer[];
  onEdit: (farmer: Farmer) => void;
  onDelete: (id: string) => void;
  onViewDetails: (farmer: Farmer) => void;
}

const FarmerList: React.FC<FarmerListProps> = ({ farmers, onViewDetails, onDelete, onEdit }) => {
  if (farmers.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 p-20 rounded-[3rem] text-center border-4 border-dashed border-gray-100 dark:border-slate-800 animate-pulse">
        <i className="fa fa-box-open text-7xl text-gray-200 dark:text-slate-800 mb-6"></i>
        <h3 className="text-xl font-black text-gray-300 dark:text-slate-700 uppercase tracking-widest">তালিকা খালি</h3>
        <p className="text-gray-400 dark:text-slate-500 text-sm mt-2">এখনো কোনো কৃষক নিবন্ধিত হয়নি।</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-slate-800 overflow-hidden">
      <ul className="divide-y divide-gray-50 dark:divide-slate-800">
        {farmers.map((farmer, idx) => (
          <li 
            key={farmer.id} 
            className="group flex flex-col sm:flex-row items-center gap-4 p-5 hover:bg-green-50/30 dark:hover:bg-green-950/20 transition-all duration-300"
          >
            {/* সিরিয়াল নাম্বার ও ফটো */}
            <div className="flex items-center gap-4 w-full sm:w-auto">
              <span className="w-8 text-center text-xs font-black text-gray-300 dark:text-slate-700 group-hover:text-green-500 transition-colors">
                {toBengaliNumber(idx + 1)}
              </span>
              <div className="relative w-16 h-16 flex-shrink-0">
                <img 
                  src={farmer.photo || `https://ui-avatars.com/api/?name=${encodeURIComponent(farmer.name)}&background=f0fdf4&color=166534`} 
                  className="w-full h-full rounded-2xl object-cover border-2 border-white dark:border-slate-800 shadow-sm" 
                  alt={farmer.nameBangla} 
                />
              </div>
            </div>

            {/* কৃষকের নাম ও বেসিক তথ্য */}
            <div className="flex-1 min-w-0 w-full">
              <h3 className="font-bold text-gray-800 dark:text-slate-100 text-lg group-hover:text-green-700 dark:group-hover:text-green-400 transition-colors">
                {farmer.nameBangla}
              </h3>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1">
                <p className="text-xs text-gray-400 dark:text-slate-500 flex items-center gap-1">
                  <i className="fa fa-phone text-[10px] text-green-500"></i>
                  {toBengaliNumber(farmer.mobile)}
                </p>
                <p className="text-xs text-gray-400 dark:text-slate-500 flex items-center gap-1">
                  <i className="fa fa-id-card text-[10px] text-blue-500"></i>
                  {toBengaliNumber(farmer.nid)}
                </p>
                <p className="text-xs text-gray-400 dark:text-slate-500 flex items-center gap-1">
                  <i className="fa fa-location-dot text-[10px] text-red-400"></i>
                  {farmer.village}
                </p>
              </div>
            </div>

            {/* অ্যাকশন বাটনসমূহ */}
            <div className="flex items-center gap-2 w-full sm:w-auto justify-end mt-2 sm:mt-0">
              <button 
                onClick={() => onViewDetails(farmer)} 
                className="p-3 bg-gray-50 dark:bg-slate-800 text-gray-500 dark:text-slate-400 hover:bg-green-600 hover:text-white rounded-xl transition-all active:scale-90"
                title="বিস্তারিত"
              >
                <i className="fa fa-eye text-sm"></i>
              </button>
              <button 
                onClick={() => onEdit(farmer)} 
                className="p-3 bg-gray-50 dark:bg-slate-800 text-blue-500 hover:bg-blue-600 hover:text-white rounded-xl transition-all active:scale-90"
                title="এডিট"
              >
                <i className="fa fa-pen text-sm"></i>
              </button>
              <button 
                onClick={() => onDelete(farmer.id)} 
                className="p-3 bg-gray-50 dark:bg-slate-800 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition-all active:scale-90"
                title="মুছে ফেলুন"
              >
                <i className="fa fa-trash-alt text-sm"></i>
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default FarmerList;
