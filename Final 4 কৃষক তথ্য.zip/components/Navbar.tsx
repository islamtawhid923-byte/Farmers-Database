
import React from 'react';
import { User, ViewState } from '../types';

interface NavbarProps {
  user: User;
  onLogout: () => void;
  setView: (view: ViewState) => void;
  onDownload: () => void;
  theme: 'light' | 'dark' | 'system';
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, onLogout, setView, theme, setTheme }) => {
  const DEFAULT_IMAGE = "https://raw.githubusercontent.com/Mirza-Tawhid/cdn/main/profile.jpg";

  const toggleTheme = () => {
    if (theme === 'light') setTheme('dark');
    else if (theme === 'dark') setTheme('system');
    else setTheme('light');
  };

  const themeIcon = () => {
    if (theme === 'light') return 'fa-sun text-orange-400';
    if (theme === 'dark') return 'fa-moon text-blue-400';
    return 'fa-desktop text-slate-400';
  };

  return (
    <nav className="fixed top-4 left-4 right-4 z-50">
      <div className="max-w-6xl mx-auto bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl border border-white/40 dark:border-slate-800/40 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] rounded-[2rem] px-6 h-16 flex items-center justify-between transition-all duration-500">
        
        {/* Smart Logo */}
        <div 
          className="flex items-center gap-3 cursor-pointer group active:scale-95 transition-all" 
          onClick={() => setView('LIST')}
        >
          <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-green-200 dark:shadow-none group-hover:rotate-12 transition-transform">
            <i className="fa fa-leaf text-lg"></i>
          </div>
          <span className="text-lg font-black bg-gradient-to-r from-green-800 to-emerald-900 dark:from-green-400 dark:to-emerald-500 bg-clip-text text-transparent hidden sm:block tracking-tight">কৃষক তথ্য</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Theme Toggle Button */}
          <button 
            onClick={toggleTheme}
            className="w-10 h-10 flex items-center justify-center bg-white/50 dark:bg-slate-800/50 hover:bg-white dark:hover:bg-slate-800 rounded-xl transition-all border border-transparent hover:border-gray-100 dark:hover:border-slate-700 group"
            title={`Theme: ${theme}`}
          >
            <i className={`fa ${themeIcon()} text-sm transition-transform group-active:rotate-90`}></i>
          </button>

          <div className="w-[1px] h-6 bg-gray-200 dark:bg-slate-800 mx-1"></div>

          {/* Smart Profile Trigger */}
          <div 
            className="flex items-center gap-3 cursor-pointer p-1 pr-4 bg-white/50 dark:bg-slate-800/50 hover:bg-white dark:hover:bg-slate-800 rounded-2xl transition-all border border-transparent hover:border-green-100 dark:hover:border-green-900 group" 
            onClick={() => setView('PROFILE')}
          >
            <div className="relative">
              <img 
                src={user.photo || DEFAULT_IMAGE} 
                className="w-9 h-9 rounded-xl object-cover border-2 border-white dark:border-slate-950 shadow-sm transition-all group-hover:rounded-2xl" 
                alt="Profile" 
              />
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white dark:border-slate-950 rounded-full"></div>
            </div>
            <div className="hidden sm:block">
              <p className="text-xs font-black text-gray-800 dark:text-white leading-none mb-1">
                {user.nameBangla || user.name}
              </p>
              <p className="text-[9px] text-green-600 dark:text-green-400 font-black uppercase tracking-wider opacity-90">উপ-সহকারী কৃষি অফিসার</p>
            </div>
          </div>
          
          <div className="w-[1px] h-8 bg-gray-200 dark:bg-slate-800 mx-2 hidden sm:block"></div>

          <button 
            onClick={onLogout} 
            className="w-10 h-10 flex items-center justify-center text-gray-400 dark:text-slate-500 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-xl transition-all group"
            title="লগ আউট"
          >
            <i className="fa fa-power-off text-sm group-hover:scale-110"></i>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
