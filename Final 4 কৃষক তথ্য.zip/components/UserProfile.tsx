
import React, { useState, useMemo } from 'react';
import { User } from '../types';
import { BD_HIERARCHY } from '../constants';

interface UserProfileProps {
  user: User;
  setUser: (u: User) => void;
  onLogout: () => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ user, setUser, onLogout }) => {
  const [isEditing, setIsEditing] = useState(false);
  
  const [editedUser, setEditedUser] = useState<User>({
    ...user,
    id: user.id || '',
    nameBangla: user.nameBangla || '',
    name: user.name || '',
    fatherNameBangla: user.fatherNameBangla || '',
    fatherName: user.fatherName || '',
    motherNameBangla: user.motherNameBangla || '',
    motherName: user.motherName || '',
    bloodGroup: user.bloodGroup || '',
    division: user.division || '',
    district: user.district || '',
    upazila: user.upazila || '',
    nid: user.nid || '',
    workDivision: user.workDivision || '',
    workDistrict: user.workDistrict || '',
    workUpazila: user.workUpazila || '',
    workUnion: user.workUnion || '',
    workBlock: user.workBlock || '',
  });

  const save = () => {
    setUser(editedUser);
    setIsEditing(false);
    alert('প্রোফাইল তথ্য সফলভাবে আপডেট হয়েছে এবং সিস্টেম এটি মনে রাখবে।');
  };

  const downloadProfileData = () => {
    const data = `নাম: ${editedUser.nameBangla || '—'}\nEnglish Name: ${editedUser.name || '—'}\nপদবি: উপ-সহকারী কৃষি অফিসার\nমোবাইল: ${editedUser.id}\nরক্তের গ্রুপ: ${editedUser.bloodGroup || '—'}\nএনআইডি: ${editedUser.nid || '—'}\nস্থায়ী ঠিকানা: ${editedUser.upazila || '—'}, ${editedUser.district || '—'}\nকর্মস্থল: ${editedUser.workUpazila || '—'}, ${editedUser.workDistrict || '—'}`;
    const blob = new Blob(["\ufeff" + data], { type: 'text/plain;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SAAO_Profile_${editedUser.id}.txt`;
    a.click();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditedUser(prev => {
      const newState = { ...prev, [name]: value };
      
      if (name === 'division') {
        newState.district = ''; newState.upazila = '';
      } else if (name === 'district') {
        newState.upazila = '';
      }

      if (name === 'workDivision') {
        newState.workDistrict = ''; newState.workUpazila = ''; newState.workUnion = '';
      } else if (name === 'workDistrict') {
        newState.workUpazila = ''; newState.workUnion = '';
      } else if (name === 'workUpazila') {
        newState.workUnion = '';
      }
      return newState;
    });
  };

  const divisions = useMemo(() => Object.keys(BD_HIERARCHY), []);
  const districts = useMemo(() => editedUser.division ? Object.keys(BD_HIERARCHY[editedUser.division] || {}) : [], [editedUser.division]);
  const upazilas = useMemo(() => (editedUser.division && editedUser.district) ? Object.keys(BD_HIERARCHY[editedUser.division]?.[editedUser.district] || {}) : [], [editedUser.division, editedUser.district]);

  const workDivisions = useMemo(() => Object.keys(BD_HIERARCHY), []);
  const workDistricts = useMemo(() => editedUser.workDivision ? Object.keys(BD_HIERARCHY[editedUser.workDivision] || {}) : [], [editedUser.workDivision]);
  const workUpazilas = useMemo(() => (editedUser.workDivision && editedUser.workDistrict) ? Object.keys(BD_HIERARCHY[editedUser.workDivision]?.[editedUser.workDistrict] || {}) : [], [editedUser.workDivision, editedUser.workDistrict]);
  const workUnions = useMemo(() => (editedUser.workDivision && editedUser.workDistrict && editedUser.workUpazila) ? BD_HIERARCHY[editedUser.workDivision]?.[editedUser.workDistrict]?.[editedUser.workUpazila] || [] : [], [editedUser.workDivision, editedUser.workDistrict, editedUser.workUpazila]);

  return (
    <div className="max-w-4xl mx-auto animate-slide-up pb-10">
      <div className="bg-white dark:bg-slate-900 rounded-[3.5rem] shadow-2xl shadow-green-100/50 dark:shadow-none overflow-hidden border border-gray-100 dark:border-slate-800">
        <div className="h-60 bg-gradient-to-br from-green-600 via-emerald-700 to-teal-800 relative">
          <div className="absolute inset-0 opacity-20" style={{backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '32px 32px'}}></div>
          
          <div className="absolute top-8 right-8">
             <button 
                onClick={() => setIsEditing(!isEditing)}
                className={`w-14 h-14 flex items-center justify-center rounded-2xl transition-all shadow-xl border border-white/40 dark:border-slate-700/40 backdrop-blur-md ${isEditing ? 'bg-red-500 text-white' : 'bg-white/20 text-white hover:bg-white/40'}`}
             >
                <i className={`fa ${isEditing ? 'fa-times' : 'fa-pen-nib'}`}></i>
             </button>
          </div>
        </div>
        
        <div className="px-8 md:px-14 pb-14 -mt-28 relative z-10">
          <div className="flex flex-col md:flex-row items-center md:items-end gap-10 mb-16">
            <div className="relative group">
              <div className="w-48 h-48 rounded-[3rem] p-1.5 bg-white dark:bg-slate-950 shadow-2xl relative overflow-hidden">
                <img 
                  src={editedUser.photo || "https://raw.githubusercontent.com/Mirza-Tawhid/cdn/main/profile.jpg"} 
                  className="w-full h-full rounded-[2.8rem] object-cover bg-gray-50 dark:bg-slate-900" 
                  alt="Officer" 
                />
                <button 
                  onClick={downloadProfileData}
                  className="absolute bottom-4 right-4 w-10 h-10 bg-green-600 text-white rounded-xl flex items-center justify-center shadow-lg hover:bg-green-700 transition-all opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0"
                  title="তথ্য ডাউনলোড"
                >
                  <i className="fa fa-download"></i>
                </button>
              </div>

              {isEditing && (
                <label className="absolute -top-2 -left-2 bg-emerald-500 text-white w-12 h-12 rounded-2xl shadow-xl cursor-pointer flex items-center justify-center border-4 border-white dark:border-slate-950 hover:scale-110 transition-transform">
                  <i className="fa fa-camera"></i>
                  <input type="file" className="hidden" onChange={e => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onloadend = () => setEditedUser({...editedUser, photo: reader.result as string});
                      reader.readAsDataURL(file);
                    }
                  }} />
                </label>
              )}
            </div>
            
            <div className="flex-1 text-center md:text-left mb-6">
              <h2 className="text-4xl font-black text-gray-800 dark:text-white tracking-tight mb-2">
                {editedUser.nameBangla || 'অফিসার নাম'}
              </h2>
              <div className="flex flex-col items-center md:items-start gap-2">
                <span className="px-5 py-2 bg-green-600 text-white rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-lg shadow-green-100 dark:shadow-none">
                   উপ-সহকারী কৃষি অফিসার
                </span>
                <p className="text-gray-400 dark:text-slate-500 text-xs font-bold mt-2 flex items-center gap-2">
                  <i className="fa fa-map-marker-alt text-green-500"></i> 
                  {editedUser.workUpazila ? editedUser.workUpazila : 'উপজেলা'}, {editedUser.workDistrict ? editedUser.workDistrict : 'জেলা'}
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div className="space-y-10">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-gray-500 dark:text-slate-400 shadow-inner">
                  <i className="fa fa-fingerprint text-xl"></i>
                </div>
                <h3 className="text-sm font-black text-gray-800 dark:text-white uppercase tracking-[0.2em]">ব্যক্তিগত পরিচয় ও স্থায়ী ঠিকানা</h3>
              </div>
              
              <div className="grid grid-cols-1 gap-8">
                <div className="grid grid-cols-2 gap-6">
                  <SmartInput label="নাম (বাংলা)" name="nameBangla" value={editedUser.nameBangla} disabled={!isEditing} onChange={handleInputChange} />
                  <SmartInput label="Name (English)" name="name" value={editedUser.name} disabled={!isEditing} onChange={handleInputChange} />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <SmartInput label="পিতার নাম (বাংলা)" name="fatherNameBangla" value={editedUser.fatherNameBangla} disabled={!isEditing} onChange={handleInputChange} />
                  <SmartInput label="Father Name (Eng)" name="fatherName" value={editedUser.fatherName} disabled={!isEditing} onChange={handleInputChange} />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <SmartInput label="মাতার নাম (বাংলা)" name="motherNameBangla" value={editedUser.motherNameBangla} disabled={!isEditing} onChange={handleInputChange} />
                  <SmartInput label="Mother Name (Eng)" name="motherName" value={editedUser.motherName} disabled={!isEditing} onChange={handleInputChange} />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <SmartInput label="মোবাইল আইডি" name="id" value={editedUser.id} disabled={true} onChange={handleInputChange} bold />
                  <SmartSelect label="রক্তের গ্রুপ" name="bloodGroup" value={editedUser.bloodGroup} disabled={!isEditing} onChange={handleInputChange} options={['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']} />
                </div>
                <div className="grid grid-cols-1 gap-6">
                   <SmartInput label="এনআইডি (NID)" name="nid" value={editedUser.nid} disabled={!isEditing} onChange={handleInputChange} />
                </div>
                <div className="bg-gray-50/50 dark:bg-slate-950 p-6 rounded-[2rem] border border-gray-100 dark:border-slate-800 space-y-6">
                  <p className="text-[10px] font-black text-gray-400 dark:text-slate-600 uppercase tracking-widest border-b dark:border-slate-800 pb-2">স্থায়ী ঠিকানা</p>
                  <div className="grid grid-cols-2 gap-4">
                    <SmartSelect label="বিভাগ" name="division" value={editedUser.division} disabled={!isEditing} onChange={handleInputChange} options={divisions} />
                    <SmartSelect label="জেলা" name="district" value={editedUser.district} disabled={!isEditing} onChange={handleInputChange} options={districts} />
                  </div>
                  <SmartSelect label="উপজেলা" name="upazila" value={editedUser.upazila} disabled={!isEditing} onChange={handleInputChange} options={upazilas} />
                </div>
              </div>
            </div>

            <div className="space-y-10">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 flex items-center justify-center text-emerald-500 dark:text-emerald-400 shadow-inner">
                  <i className="fa fa-shield-halved text-xl"></i>
                </div>
                <h3 className="text-sm font-black text-emerald-600 dark:text-emerald-500 uppercase tracking-[0.2em]">কর্মস্থল তথ্য</h3>
              </div>

              <div className="bg-emerald-50/40 dark:bg-emerald-950/20 rounded-[3rem] p-10 space-y-8 border border-emerald-100/50 dark:border-emerald-900/30 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-100/30 dark:bg-emerald-900/10 rounded-full -mr-16 -mt-16"></div>
                
                <div className="grid grid-cols-2 gap-6">
                  <SmartSelect label="বিভাগ" name="workDivision" value={editedUser.workDivision} disabled={!isEditing} onChange={handleInputChange} options={workDivisions} />
                  <SmartSelect label="জেলা" name="workDistrict" value={editedUser.workDistrict} disabled={!isEditing} onChange={handleInputChange} options={workDistricts} />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <SmartSelect label="উপজেলা" name="workUpazila" value={editedUser.workUpazila} disabled={!isEditing} onChange={handleInputChange} options={workUpazilas} />
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-emerald-600 dark:text-emerald-500 uppercase ml-1 opacity-70">ইউনিয়ন</label>
                    {isEditing ? (
                      <select name="workUnion" value={editedUser.workUnion || ''} onChange={handleInputChange}
                        className="w-full p-4 bg-white dark:bg-slate-900 rounded-2xl border border-emerald-200 dark:border-emerald-800 outline-none text-sm font-bold shadow-sm focus:ring-4 focus:ring-emerald-100 dark:focus:ring-emerald-950 transition-all text-gray-800 dark:text-white">
                        <option value="">নির্বাচন</option>
                        {workUnions.map(u => <option key={u} value={u}>{u}</option>)}
                      </select>
                    ) : (
                      <div className="p-4 bg-white/60 dark:bg-slate-900 rounded-2xl text-sm font-bold text-gray-700 dark:text-slate-200 shadow-sm border border-emerald-100/50 dark:border-emerald-900/50">{editedUser.workUnion || '—'}</div>
                    )}
                  </div>
                </div>
                <SmartInput label="ব্লক নাম (Block)" name="workBlock" value={editedUser.workBlock} disabled={!isEditing} onChange={handleInputChange} />
              </div>
            </div>
          </div>

          {isEditing && (
            <div className="mt-16 flex justify-center">
              <button 
                onClick={save} 
                className="px-14 py-5 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-black rounded-[2.5rem] shadow-2xl shadow-green-200 dark:shadow-none hover:scale-105 active:scale-95 transition-all flex items-center gap-4 text-lg"
              >
                <i className="fa fa-save"></i> প্রোফাইল আপডেট করুন
              </button>
            </div>
          )}
          
          <div className="mt-24 flex flex-col items-center pt-10">
            <button 
              onClick={onLogout} 
              className="group flex items-center gap-3 px-10 py-5 bg-gray-900 dark:bg-slate-950 text-white font-black rounded-3xl hover:bg-red-600 transition-all duration-500 shadow-xl"
            >
              <i className="fa fa-power-off group-hover:rotate-180 transition-transform"></i> লগ আউট করুন
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const SmartInput = ({ label, name, value, disabled, onChange, bold }: any) => (
  <div className="space-y-2">
    <label className="text-[10px] font-black text-gray-400 dark:text-slate-600 uppercase ml-1 opacity-80 tracking-widest">{label}</label>
    {disabled ? (
      <div className={`p-4 bg-gray-50/60 dark:bg-slate-950 rounded-2xl text-sm font-bold text-gray-700 dark:text-slate-200 border border-gray-100/50 dark:border-slate-800 shadow-sm ${bold ? 'text-green-700 dark:text-green-500 font-mono' : ''}`}>
        {value || '—'}
      </div>
    ) : (
      <input 
        type="text" 
        name={name} 
        value={value || ''} 
        onChange={onChange}
        className="w-full p-4 bg-white dark:bg-slate-900 rounded-2xl border border-gray-200 dark:border-slate-800 outline-none text-sm font-bold shadow-sm focus:ring-4 focus:ring-green-100 dark:focus:ring-green-950 focus:border-green-500 dark:focus:border-green-600 transition-all text-gray-800 dark:text-white" 
      />
    )}
  </div>
);

const SmartSelect = ({ label, name, value, disabled, onChange, options }: any) => (
  <div className="space-y-2">
    <label className="text-[10px] font-black text-gray-400 dark:text-slate-600 uppercase ml-1 opacity-70 tracking-widest">{label}</label>
    {disabled ? (
      <div className="p-4 bg-white/60 dark:bg-slate-950 rounded-2xl text-sm font-bold text-gray-700 dark:text-slate-200 shadow-sm border border-gray-100/50 dark:border-slate-800">{value || '—'}</div>
    ) : (
      <select 
        name={name} 
        value={value || ''} 
        onChange={onChange}
        className="w-full p-4 bg-white dark:bg-slate-900 rounded-2xl border border-gray-200 dark:border-slate-800 outline-none text-sm font-bold shadow-sm focus:ring-4 focus:ring-green-100 dark:focus:ring-green-950 transition-all text-gray-800 dark:text-white"
      >
        <option value="">নির্বাচন</option>
        {options.map((o: string) => <option key={o} value={o}>{o}</option>)}
      </select>
    )}
  </div>
);

export default UserProfile;
