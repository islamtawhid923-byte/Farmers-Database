
import React, { useState, useEffect } from 'react';
import { getFarmingInsights } from '../services/geminiService';
import { Farmer } from '../types';

interface AiInsightsProps {
  farmers: Farmer[];
}

export const AiInsights: React.FC<AiInsightsProps> = ({ farmers }) => {
  const [insight, setInsight] = useState<string | undefined>("");
  const [loading, setLoading] = useState(false);

  const fetchInsights = async () => {
    if (farmers.length === 0) return;
    setLoading(true);
    const result = await getFarmingInsights(farmers);
    setInsight(result);
    setLoading(false);
  };

  useEffect(() => {
    if (farmers.length > 0) {
      fetchInsights();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="bg-gradient-to-br from-emerald-500 to-green-600 text-white p-6 rounded-2xl shadow-lg mb-8">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <i className="fas fa-robot text-2xl"></i>
          <h2 className="text-xl font-bold">কৃষি এআই বিশেষজ্ঞ পরামর্শ</h2>
        </div>
        <button 
          onClick={fetchInsights}
          disabled={loading}
          className="bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg text-sm transition-all"
        >
          {loading ? 'বিশ্লেষণ হচ্ছে...' : <i className="fas fa-sync-alt"></i>}
        </button>
      </div>
      
      {loading ? (
        <div className="animate-pulse space-y-2">
          <div className="h-4 bg-white/20 rounded w-3/4"></div>
          <div className="h-4 bg-white/20 rounded w-1/2"></div>
        </div>
      ) : (
        <div className="prose prose-invert max-w-none whitespace-pre-line text-green-50">
          {insight || 'কৃষকদের তথ্য যোগ করলে এখানে কৃত্রিম বুদ্ধিমত্তার বিশ্লেষণ দেখা যাবে।'}
        </div>
      )}
    </div>
  );
};
