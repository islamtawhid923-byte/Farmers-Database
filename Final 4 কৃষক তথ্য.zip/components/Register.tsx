
import React, { useState, useEffect, useRef } from 'react';

interface RegisterProps {
  onRegisterSuccess: (name: string, mobile: string) => void;
  onBackToLogin: () => void;
}

const Register: React.FC<RegisterProps> = ({ onRegisterSuccess, onBackToLogin }) => {
  const [step, setStep] = useState<'FORM' | 'OTP'>('FORM');
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [otp, setOtp] = useState(['', '', '', '']);
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120);
  
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (step === 'OTP' && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [step, timeLeft]);

  const generateRandomOtp = () => {
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(code);
    return code;
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Normalize mobile number
    let finalMobile = mobile.replace(/[^0-9]/g, '');
    if (finalMobile.length === 10 && !finalMobile.startsWith('0')) finalMobile = '0' + finalMobile;
    
    if (finalMobile.length !== 11) { 
      alert("সঠিক ১১ সংখ্যার মোবাইল নম্বর দিন।"); 
      return; 
    }

    // UNIQUE REGISTRATION CHECK
    const saved = localStorage.getItem('agro_registered_users_list');
    const users = saved ? JSON.parse(saved) : [];
    const existingUser = users.find((u: any) => u.mobile === finalMobile);
    
    if (existingUser) {
      alert("এই নম্বরটি ইতিমধ্যে নিবন্ধিত হয়েছে। দয়া করে লগইন করুন অথবা অন্য নম্বর ব্যবহার করুন।");
      return;
    }

    // STRICT 4 DIGIT PASSWORD CHECK
    if (password.length !== 4) { 
      alert("পাসওয়ার্ড ঠিক ৪ সংখ্যার হতে হবে।"); 
      return; 
    }
    if (password !== confirmPassword) { 
      alert("পাসওয়ার্ড দুটি মিলছে না!"); 
      return; 
    }

    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      generateRandomOtp();
      setShowPopup(true);
    }, 1500);
  };

  const startVerification = () => {
    setShowPopup(false);
    setStep('OTP');
    setTimeLeft(120);
  };

  const handleOtpChange = (index: number, value: string) => {
    const val = value.replace(/[^0-9]/g, '');
    const newOtp = [...otp];
    newOtp[index] = val.slice(-1);
    setOtp(newOtp);
    if (val && index < 3) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      if (nextInput) (nextInput as HTMLInputElement).focus();
    }
  };

  const verifyOtp = () => {
    if (timeLeft === 0) { 
      alert("ওটিপি কোডটির মেয়াদ শেষ হয়ে গেছে।"); 
      return; 
    }
    if (otp.join('') === generatedOtp) {
      const saved = localStorage.getItem('agro_registered_users_list');
      const users = saved ? JSON.parse(saved) : [];
      let finalMobile = mobile.replace(/[^0-9]/g, '');
      if (finalMobile.length === 10 && !finalMobile.startsWith('0')) finalMobile = '0' + finalMobile;
      
      // Save to persistent storage
      users.push({ name, mobile: finalMobile, password });
      localStorage.setItem('agro_registered_users_list', JSON.stringify(users));
      
      onRegisterSuccess(name, finalMobile);
    } else {
      alert("ভুল ওটিপি কোড!");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#fcfdfe] dark:bg-slate-950 p-4 relative overflow-hidden font-['Hind_Siliguri'] transition-colors duration-500">
      <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-green-100/40 dark:bg-green-900/10 rounded-full blur-[100px] animate-pulse"></div>
      <div className="absolute bottom-[-10%] left-[-5%] w-[500px] h-[500px] bg-emerald-100/30 dark:bg-emerald-900/10 rounded-full blur-[100px] animate-pulse" style={{animationDelay: '2s'}}></div>

      {showPopup && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-md animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-10 max-w-sm w-full shadow-2xl text-center space-y-6 animate-slide-up border border-white/50 dark:border-slate-800">
            <div className="w-20 h-20 bg-green-50 dark:bg-green-950 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto ring-4 ring-green-50 dark:ring-green-900/20">
              <i className="fa-solid fa-paper-plane text-3xl"></i>
            </div>
            <div>
              <h3 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">ভেরিফিকেশন</h3>
              <p className="text-gray-400 dark:text-slate-500 text-[10px] font-black uppercase tracking-widest mt-1">নিবন্ধনের ওটিপি কোড</p>
            </div>
            <div className="bg-slate-50 dark:bg-slate-950 py-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-inner">
               <span className="text-5xl font-black text-green-600 dark:text-green-400 tracking-[0.2em] font-mono pl-3">{generatedOtp}</span>
            </div>
            <button 
              onClick={startVerification} 
              className="w-full bg-gray-900 dark:bg-green-600 hover:bg-green-600 dark:hover:bg-green-700 text-white py-5 rounded-2xl font-black transition-all active:scale-95 shadow-lg"
            >
              কোড নিশ্চিত করুন
            </button>
          </div>
        </div>
      )}

      <div className="w-full max-w-lg bg-white/90 dark:bg-slate-900/90 backdrop-blur-2xl rounded-[3.5rem] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.08)] border border-white dark:border-slate-800 p-10 relative z-10">
        {step === 'FORM' ? (
          <div className="space-y-8 animate-slide-up">
            <div className="text-center space-y-3">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-[2rem] flex items-center justify-center mx-auto shadow-xl transform hover:rotate-6 transition-all duration-500">
                <i className="fa-solid fa-user-plus text-3xl"></i>
              </div>
              <div>
                <h2 className="text-3xl font-black text-gray-900 dark:text-white tracking-tight leading-none mb-1">নতুন নিবন্ধন</h2>
                <p className="text-green-600 dark:text-green-400 text-sm font-bold tracking-widest uppercase">কৃষক তথ্য ব্যবস্থাপনা</p>
              </div>
            </div>

            <form onSubmit={handleRegisterSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[11px] font-black text-gray-400 dark:text-slate-500 uppercase ml-4 tracking-widest">আপনার নাম</label>
                <div className="relative group">
                  <div className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-green-600 transition-colors">
                    <i className="fa-solid fa-signature"></i>
                  </div>
                  <input 
                    type="text" 
                    value={name} 
                    onChange={e => setName(e.target.value)} 
                    className="w-full pl-16 pr-6 py-5 bg-slate-50/80 dark:bg-slate-950/80 border-2 border-transparent focus:border-green-500 dark:focus:border-green-600 focus:bg-white dark:focus:bg-slate-900 rounded-2xl outline-none font-bold text-gray-800 dark:text-white transition-all shadow-sm" 
                    placeholder="নাম লিখুন" 
                    required 
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-black text-gray-400 dark:text-slate-500 uppercase ml-4 tracking-widest">মোবাইল নম্বর</label>
                <div className="flex bg-slate-50/80 dark:bg-slate-950/80 rounded-2xl border-2 border-transparent focus-within:border-green-500 dark:focus-within:border-green-600 focus-within:bg-white dark:focus-within:bg-slate-900 transition-all overflow-hidden shadow-sm">
                  <div className="pl-6 pr-4 py-5 flex items-center gap-3 border-r border-slate-100/50 dark:border-slate-800 bg-slate-100/10">
                    <div className="w-7 h-4 rounded-sm overflow-hidden shadow-sm flex-shrink-0">
                        <svg viewBox="0 0 10 6" className="w-full h-full">
                          <rect width="10" height="6" fill="#006a4e"/>
                          <circle cx="4.5" cy="3" r="2" fill="#f42a41"/>
                        </svg>
                    </div>
                    <span className="font-bold text-gray-700 dark:text-slate-300 font-mono text-lg">+880</span>
                  </div>
                  <input 
                    type="tel" 
                    value={mobile} 
                    onChange={e => setMobile(e.target.value.replace(/[^0-9]/g, '').slice(0,11))} 
                    className="w-full px-5 py-5 bg-transparent outline-none font-black text-xl text-gray-800 dark:text-white tracking-wider font-mono" 
                    placeholder="XXXXXXXXXX" 
                    required 
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[11px] font-black text-gray-400 dark:text-slate-500 uppercase ml-4 tracking-widest">পাসওয়ার্ড (৪ সংখ্যা)</label>
                  <div className="relative group">
                    <input 
                      type={showPass ? "text" : "password"} 
                      value={password} 
                      onChange={e => setPassword(e.target.value.replace(/[^0-9]/g, '').slice(0,4))} 
                      maxLength={4}
                      className="w-full p-5 bg-slate-50/80 dark:bg-slate-950/80 border-2 border-transparent focus:border-green-500 dark:focus:border-green-600 focus:bg-white dark:focus:bg-slate-900 rounded-2xl outline-none font-black text-center text-xl transition-all shadow-sm text-gray-800 dark:text-white" 
                      placeholder="****" 
                      required 
                    />
                    <button 
                      type="button"
                      onClick={() => setShowPass(!showPass)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 hover:text-green-500 transition-colors"
                    >
                      <i className={`fa-solid ${showPass ? 'fa-eye-slash' : 'fa-eye'} text-xs`}></i>
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[11px] font-black text-gray-400 dark:text-slate-500 uppercase ml-4 tracking-widest">নিশ্চিত করুন</label>
                  <div className="relative group">
                    <input 
                      type={showConfirmPass ? "text" : "password"} 
                      value={confirmPassword} 
                      onChange={e => setConfirmPassword(e.target.value.replace(/[^0-9]/g, '').slice(0,4))} 
                      maxLength={4}
                      className="w-full p-5 bg-slate-50/80 dark:bg-slate-950/80 border-2 border-transparent focus:border-green-500 dark:focus:border-green-600 focus:bg-white dark:focus:bg-slate-900 rounded-2xl outline-none font-black text-center text-xl transition-all shadow-sm text-gray-800 dark:text-white" 
                      placeholder="****" 
                      required 
                    />
                    <button 
                      type="button"
                      onClick={() => setShowConfirmPass(!showConfirmPass)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 hover:text-green-500 transition-colors"
                    >
                      <i className={`fa-solid ${showConfirmPass ? 'fa-eye-slash' : 'fa-eye'} text-xs`}></i>
                    </button>
                  </div>
                </div>
              </div>

              <button 
                type="submit" 
                disabled={isSending} 
                className="w-full bg-gray-900 dark:bg-green-600 hover:bg-green-600 dark:hover:bg-green-700 text-white py-6 rounded-[2rem] font-black shadow-2xl shadow-green-100 dark:shadow-none transition-all flex items-center justify-center gap-4 text-lg mt-4 active:scale-[0.98] disabled:opacity-50"
              >
                {isSending ? (
                  <i className="fa-solid fa-circle-notch animate-spin"></i>
                ) : (
                  <i className="fa-solid fa-shield-check"></i>
                )}
                {isSending ? 'অপেক্ষা করুন' : 'নিবন্ধন সম্পন্ন করুন'}
              </button>
            </form>
          </div>
        ) : (
          <div className="space-y-10 animate-slide-up">
            <div className="text-center space-y-3">
              <div className="w-20 h-20 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-3xl flex items-center justify-center mx-auto ring-2 ring-emerald-100 dark:ring-emerald-900">
                <i className="fa-solid fa-key-skeleton text-3xl"></i>
              </div>
              <h2 className="text-3xl font-black text-gray-900 dark:text-white">কোড দিন</h2>
              <p className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase tracking-widest">আপনার মোবাইলে পাঠানো ৪ সংখ্যার কোড</p>
            </div>

            <div className="flex justify-center gap-3">
              {otp.map((d, i) => (
                <input 
                  key={i} 
                  id={`otp-${i}`} 
                  type="text" 
                  value={d} 
                  onChange={e => handleOtpChange(i, e.target.value)} 
                  className="w-16 h-20 text-center text-4xl font-black border-2 border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 text-gray-800 dark:text-white rounded-2xl focus:border-green-600 outline-none transition-all shadow-sm" 
                  maxLength={1}
                />
              ))}
            </div>

            <div className="space-y-6">
              <button 
                onClick={verifyOtp} 
                className="w-full bg-green-600 hover:bg-green-700 text-white py-6 rounded-2xl font-black shadow-lg text-lg transition-all active:scale-95 flex items-center justify-center gap-3"
              >
                সম্পন্ন করুন <i className="fa-solid fa-circle-check"></i>
              </button>
              
              <div className="text-center">
                 <div className="inline-flex items-center gap-3 px-6 py-3 bg-slate-50 dark:bg-slate-950 rounded-full border border-slate-100 dark:border-slate-800">
                   <i className="fa-solid fa-hourglass-half text-green-500"></i>
                   <p className="text-[11px] font-black text-gray-500 dark:text-slate-500 font-mono">
                     TIME: <span className={timeLeft < 30 ? 'text-red-500' : 'text-green-600'}>{Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}</span>
                   </p>
                 </div>
              </div>
            </div>
          </div>
        )}

        <div className="mt-12 pt-8 border-t border-slate-50 dark:border-slate-800 text-center">
          <button 
            onClick={onBackToLogin} 
            className="group text-[11px] uppercase tracking-[0.25em] font-black text-gray-400 dark:text-slate-500 hover:text-green-600 dark:hover:text-green-400 transition-all flex items-center justify-center gap-3 mx-auto"
          >
            <i className="fa-solid fa-arrow-left group-hover:-translate-x-1 transition-transform"></i>
            লগইন ফিরে যান
          </button>
        </div>
      </div>
    </div>
  );
};

export default Register;
